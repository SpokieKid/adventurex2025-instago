//
//  InstaGoTests.swift
//  InstaGoTests
//
//  Created by 陈瀚翔 on 23/7/2025.
//

import Testing
@testable import InstaGo

struct InstaGoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
